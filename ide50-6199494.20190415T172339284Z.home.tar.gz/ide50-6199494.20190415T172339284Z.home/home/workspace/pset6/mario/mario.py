import cs50

while True:
    print("height: ", end="")
    entered=cs50.get_int()
    if entered>0 or entered< 23:
        break

for rows in range(entered):
    print(" " * (entered-rows),end="")
    print("#" * (rows+2),end="")
    print("")