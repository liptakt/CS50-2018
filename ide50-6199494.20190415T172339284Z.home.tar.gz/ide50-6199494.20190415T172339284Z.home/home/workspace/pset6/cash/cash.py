import cs50

while True:
    print("Change owed:",end="")
    change=cs50.get_float()
    if(change>0):
        break

change=change*100

change=round(change)

coin=change;

counter=0;

while coin>24:
    counter+=1
    coin-=25

while coin>9:
    counter+=1
    coin-=10

while coin>4:
    counter+=1
    coin-=5

while coin>0:
    counter+=1
    coin-=1

print("%d coins" % counter)