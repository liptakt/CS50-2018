import cs50
import sys

def main():
   if len(sys.ar
           translated.append(symbol) #not letter print symbol

   print("".join(translated))
   exit(0)

def caesar(char, key):
   if char.isupper():
       return chr(((ord(char) - 65 + key) % 26) + 65)
   else:
       return chr(((ord(char) - 97 + key) % 26) + 97)
gv) != 2:
       print("You should provide cmd line arguments!")
       exit(1)

    # int = atoi
   key = int(sys.argv[1])#checks what is typed at 1 for command line
   translated = [] #declaration for an array
   print("Plaintext: ",end="")
   message = cs50.get_string()# what is typed
   print("Ciphertext: ",end="")
   for symbol in message: #passing symbol into isalpha
       if symbol.isalpha():
           translated.append(caesar(symbol, key))#append adds to the end
       else:
if __name__ == "__main__":
    main()